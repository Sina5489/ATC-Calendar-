/**
 * Stale Cache Cleanup Stub
 * Automatically purges AFTN UI and stale cache if an outdated cached HTML loads this file.
 */
(function() {
  try {
    localStorage.removeItem('atc_aftn_settings');
    localStorage.removeItem('atc_aftn_telegrams_log');
    if ('caches' in window) {
      caches.keys().then(function(names) {
        names.forEach(function(n) { caches.delete(n); });
      });
    }
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then(function(regs) {
        regs.forEach(function(r) { r.unregister(); });
      });
    }
    function removeAftnElements() {
      const selectors = ['#tab-aftn', '.aftn-home-widget', '[data-tab="aftn"]', '#aftnViewContainer'];
      selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => el.remove());
      });
      if (window.appController && window.appController.currentTab === 'aftn') {
        window.appController.switchTab('home');
      }
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', removeAftnElements);
    } else {
      removeAftnElements();
    }
  } catch(e) {}
})();
window.AftnManager = {
  getInitialAftnDirectory: () => [],
  formatAftnTelegram: () => '',
  telegramsLog: [],
  loadTelegramsLog: () => []
};
