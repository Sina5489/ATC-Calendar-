/**
 * app.js
 * Main Controller for Taghvim Sina (تقویم سینا)
 * Connects all modules, handles tab switching, live timers, UI rendering, and events.
 */

class AppController {
  constructor() {
    this.cal = window.calendarEngine;
    this.shift = window.shiftCalculator;
    this.notes = window.notesManager;
    this.converter = window.dateConverter;
    this.settings = window.settingsManager;
    this.pdf = window.pdfPrintEngine;

    // Default current Jalali view date
    const todayG = new Date();
    const todayJ = this.cal.gregorianToJalali(todayG.getFullYear(), todayG.getMonth() + 1, todayG.getDate());
    
    this.currentJalaliYear = todayJ.jy;
    this.currentJalaliMonth = todayJ.jm;
    this.selectedDayForModal = null;

    this.timerInterval = null;

    // Navigation and Modal History Stack
    this.currentTab = 'home';
    this.tabHistory = ['home'];
    this.activeModals = [];

    // Initialize UI and Event Listeners
    const initApp = () => {
      this.initUI();
      this.attachEventListeners();
      this.startCountdownTimer();
    };

    if (document.readyState === 'loading') {
      window.addEventListener('DOMContentLoaded', initApp);
    } else {
      initApp();
    }
  }

  /**
   * Safe modal opener compatible with Bootstrap or pure DOM
   */
  showModal(modalId) {
    const el = document.getElementById(modalId);
    if (!el) return;

    if (!this.activeModals.includes(modalId)) {
      this.activeModals.push(modalId);
      try {
        if (typeof history !== 'undefined' && history.pushState) {
          history.pushState({ type: 'modal', modalId: modalId }, '');
        }
      } catch (e) {
        // Safe fallback in restrictive environments
      }
    }

    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      let inst = bootstrap.Modal.getInstance(el);
      if (!inst) inst = new bootstrap.Modal(el);
      inst.show();
    } else {
      el.classList.add('show');
      el.style.display = 'block';
      document.body.classList.add('modal-open');
    }
  }

  /**
   * Safe modal closer compatible with Bootstrap or pure DOM
   */
  hideModal(modalId) {
    const el = document.getElementById(modalId);
    if (!el) return;

    this.activeModals = this.activeModals.filter(id => id !== modalId);

    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      const inst = bootstrap.Modal.getInstance(el);
      if (inst) inst.hide();
    } else {
      el.classList.remove('show');
      el.style.display = 'none';
      document.body.classList.remove('modal-open');
    }

    setTimeout(() => {
      const anyModalOpen = document.querySelector('.modal.show') || (this.activeModals && this.activeModals.length > 0);
      if (!anyModalOpen) {
        document.body.classList.remove('modal-open');
        document.querySelectorAll('.modal-backdrop').forEach(bd => bd.remove());
      }
    }, 200);
  }

  /**
   * Closes all currently open modals
   */
  closeAllModals() {
    const modals = ['dayDetailModal', 'addNoteModal', 'backupModal'];
    modals.forEach(id => {
      const el = document.getElementById(id);
      if (el && (el.classList.contains('show') || el.style.display === 'block')) {
        this.hideModal(id);
      }
    });
    this.activeModals = [];
  }

  /**
   * Handles Back navigation (Hardware Back button, browser popstate, or UI back button)
   * Pops modals first, then pops tab history down to home.
   * Returns true if back action was handled, false if already at root dashboard.
   * @returns {boolean}
   */
  handleBack() {
    // 1. Check if any modal is currently visible on screen or in activeModals stack
    const openModals = Array.from(document.querySelectorAll('.modal.show'));
    if (this.activeModals.length > 0 || openModals.length > 0) {
      let targetId = null;
      if (this.activeModals.length > 0) {
        targetId = this.activeModals[this.activeModals.length - 1];
      } else if (openModals.length > 0) {
        targetId = openModals[openModals.length - 1].id;
      }

      if (targetId) {
        this.hideModal(targetId);
        return true;
      }
    }

    // 2. Check if there is tab navigation history to go back one step
    if (this.tabHistory.length > 1) {
      this.tabHistory.pop(); // Pop current tab
      const previousTab = this.tabHistory[this.tabHistory.length - 1] || 'home';
      this.switchTab(previousTab, true);
      return true;
    }

    // 3. If tabHistory is empty or only 1 item, but current active tab is not 'home'
    if (this.currentTab && this.currentTab !== 'home') {
      this.tabHistory = ['home'];
      this.switchTab('home', true);
      return true;
    }

    // 4. Already at home root dashboard with no open modals
    return false;
  }

  /**
   * Initializes main app views
   */
  initUI() {
    try {
      localStorage.removeItem('atc_aftn_settings');
      localStorage.removeItem('atc_aftn_telegrams_log');
    } catch (e) {}
    this.populateCalendarYearSuggestions();
    this.renderDashboard();
    this.renderCalendar();
    this.renderTeamPage();
    this.initDateConverter();
    this.renderNotesList();
    this.populateSettingsForm();
  }

  /**
   * Initializes date converter inputs with today's date and computes preview
   */
  initDateConverter() {
    const yearInput = document.getElementById('convYear');
    const monthSelect = document.getElementById('convMonth');
    const dayInput = document.getElementById('convDay');
    if (!yearInput || !monthSelect || !dayInput) return;

    const now = new Date();
    const todayJ = this.cal.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());

    yearInput.value = todayJ.jy;
    monthSelect.value = String(todayJ.jm);
    dayInput.value = todayJ.jd;

    const convBtn = document.getElementById('btnRunConversion');
    if (convBtn) {
      convBtn.click();
    }
  }

  /**
   * Populates the year suggestions datalist in calendar tab (1380 to 1450)
   */
  populateCalendarYearSuggestions() {
    const datalist = document.getElementById('calYearDatalist');
    if (!datalist) return;
    
    if (datalist.children.length === 0) {
      let optionsHtml = '';
      for (let y = 1380; y <= 1450; y++) {
        optionsHtml += `<option value="${y}">${this.cal.toPersianDigits(y)}</option>`;
      }
      datalist.innerHTML = optionsHtml;
    }
  }

  /**
   * Switches active navigation tab
   * @param {string} tabName ('home', 'calendar', 'teams', 'converter', 'notes', 'weather', 'settings')
   * @param {boolean} isBackNav whether this switch is triggered by back navigation
   */
  switchTab(tabName, isBackNav = false) {
    if (!tabName) return;

    // Close any active modal when switching tabs
    this.closeAllModals();

    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-item-btn').forEach(btn => btn.classList.remove('active'));

    const targetTab = document.getElementById(`tab-${tabName}`);
    if (targetTab) targetTab.classList.add('active');

    const targetNav = document.querySelector(`.nav-item-btn[data-tab="${tabName}"]`);
    if (targetNav) targetNav.classList.add('active');

    if (typeof window !== 'undefined' && typeof window.scrollTo === 'function') {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }

    // Manage history stack
    if (!isBackNav) {
      if (this.currentTab !== tabName) {
        if (this.tabHistory[this.tabHistory.length - 1] !== tabName) {
          this.tabHistory.push(tabName);
        }
        try {
          if (typeof history !== 'undefined' && history.pushState) {
            history.pushState({ type: 'tab', tab: tabName }, '');
          }
        } catch (e) {
          // Safe fallback
        }
      }
    }
    this.currentTab = tabName;

    // Refresh content when switching
    if (tabName === 'calendar') this.renderCalendar();
    if (tabName === 'teams') this.renderTeamPage();
    if (tabName === 'notes') this.renderNotesList();
  }

  /**
   * Renders the Home Dashboard tab with live today data
   */
  renderDashboard() {
    const now = new Date();
    const j = this.cal.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    const h = this.cal.gregorianToHijri(now.getFullYear(), now.getMonth() + 1, now.getDate());
    const teams = this.shift.getTeamsForDate(now);
    const dayOfYear = this.cal.getJalaliDayOfYear(j.jy, j.jm, j.jd);
    const totalDays = this.cal.getJalaliYearDays(j.jy);
    const event = this.cal.getEventForDate(j.jm, j.jd, j.jy, now.getMonth() + 1, now.getDate(), h.hm, h.hd);

    // Persian Date Header
    const monthName = this.cal.jalaliMonthNames[j.jm - 1];
    const dayOfWeekIndex = (now.getDay() + 1) % 7;
    const weekDayName = this.cal.weekDayNames[dayOfWeekIndex];

    const dashPersianDateEl = document.getElementById('dashPersianDate');
    if (dashPersianDateEl) {
      dashPersianDateEl.textContent = `${weekDayName} ${this.cal.toPersianDigits(j.jd)} ${monthName} ${this.cal.toPersianDigits(j.jy)}`;
    }

    // Gregorian & Hijri Dates
    const dashGregorianDateEl = document.getElementById('dashGregorianDate');
    if (dashGregorianDateEl) {
      dashGregorianDateEl.textContent = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    }

    const dashHijriDateEl = document.getElementById('dashHijriDate');
    if (dashHijriDateEl) {
      dashHijriDateEl.textContent = `${this.cal.toPersianDigits(h.hy)}/${this.cal.toPersianDigits(String(h.hm).padStart(2, '0'))}/${this.cal.toPersianDigits(String(h.hd).padStart(2, '0'))} هـ.ق`;
    }

    // Day of Year & Event
    const dashDayOfYearEl = document.getElementById('dashDayOfYear');
    if (dashDayOfYearEl) {
      dashDayOfYearEl.textContent = this.cal.toPersianDigits(dayOfYear);
    }

    const dashTodayEventEl = document.getElementById('dashTodayEvent');
    const dashEventIconEl = document.getElementById('dashEventIcon');

    const isFriday = ((now.getDay() + 1) % 7 === 6);
    const isHoliday = !!(event && event.holiday) || isFriday;

    let eventDisplayText = '';
    if (isHoliday) {
      if (event && event.title) {
        eventDisplayText = `${event.title} (تعطیل)`;
      } else {
        eventDisplayText = 'تعطیل (جمعه)';
      }
    } else {
      if (event && event.title) {
        eventDisplayText = event.title;
      } else {
        eventDisplayText = 'بدون مناسبت';
      }
    }

    // Determine Flag Category
    // تعطیلی را با پرچم قرمز
    // جشن را با پرچم سبز
    // عزاداری را با پرچم مشکی
    // بدون مناسبت را با پرچم طلایی
    let flagCategory = 'none';

    if (!event && !isHoliday) {
      flagCategory = 'none'; // Gold
    } else if (!event && isHoliday) {
      flagCategory = 'holiday'; // Red
    } else {
      // Event exists
      const title = event.title;
      const mourningKeywords = ['شهادت', 'رحلت', 'عاشورا', 'تاسوعا', 'اربعین', 'قیام', 'کودتا', 'کاهش بلایای', 'وفات', 'عزا', 'سوگواری'];
      const celebrationKeywords = ['عید', 'جشن', 'میلاد', 'ولادت', 'مبعث', 'نوروز', 'یلدا', 'سپندارمذگان', 'پیروزی', 'مقاومت', 'فتح', 'آغاز', 'روز', 'بزرگداشت'];

      const isMourning = mourningKeywords.some(kw => title.includes(kw));
      const isCelebration = celebrationKeywords.some(kw => title.includes(kw));

      if (isMourning) {
        flagCategory = 'mourning';
      } else if (isCelebration) {
        flagCategory = 'celebration';
      } else if (isHoliday) {
        flagCategory = 'holiday';
      } else {
        flagCategory = 'celebration';
      }
    }

    if (dashTodayEventEl) {
      dashTodayEventEl.textContent = eventDisplayText;
      dashTodayEventEl.title = eventDisplayText;
    }

    if (dashEventIconEl) {
      dashEventIconEl.className = 'bi bi-flag-fill fs-3 mb-1';
      if (flagCategory === 'mourning') {
        dashEventIconEl.style.color = '#18181B'; // Black flag
        if (dashTodayEventEl) dashTodayEventEl.style.color = '#18181B';
      } else if (flagCategory === 'celebration') {
        dashEventIconEl.style.color = '#10B981'; // Green flag
        if (dashTodayEventEl) dashTodayEventEl.style.color = '#047857';
      } else if (flagCategory === 'holiday') {
        dashEventIconEl.style.color = '#EF4444'; // Red flag
        if (dashTodayEventEl) dashTodayEventEl.style.color = '#DC2626';
      } else {
        // 'none' -> Gold flag
        dashEventIconEl.style.color = '#F59E0B'; // Gold flag
        if (dashTodayEventEl) dashTodayEventEl.style.color = '#D97706';
      }
    }

    // Today's Notes Widget
    const dateStr = `${j.jy}-${String(j.jm).padStart(2, '0')}-${String(j.jd).padStart(2, '0')}`;
    const todayNotes = this.notes.getNotesForDate(dateStr);
    const dashTodayNotesListEl = document.getElementById('dashTodayNotesList');

    if (dashTodayNotesListEl) {
      if (todayNotes.length === 0) {
        dashTodayNotesListEl.innerHTML = '<p class="text-muted text-center py-2 mb-0">یادداشتی برای امروز ثبت نشده است.</p>';
      } else {
        let html = '<div class="list-group list-group-flush">';
        todayNotes.forEach(n => {
          html += `
            <div class="list-group-item bg-transparent px-0 dash-note-item">
              <div class="dash-note-title">${n.title || 'بدون عنوان'}</div>
              <div class="dash-note-text">${n.text}</div>
            </div>
          `;
        });
        html += '</div>';
        dashTodayNotesListEl.innerHTML = html;
      }
    }

    // Active Shift Priority
    this.updateDashboardActiveShift();
  }

  /**
   * Updates dashboard active shift priority ordering and highlight styling
   */
  updateDashboardActiveShift(status) {
    if (!status) status = this.shift.getCurrentShiftStatus();

    const activeBox = document.getElementById('dashActiveTeamBox');
    const nextBox = document.getElementById('dashNextTeamBox');

    const activeIcon = document.getElementById('dashActiveIcon');
    const activeShiftName = document.getElementById('dashActiveShiftName');
    const activeTeamEl = document.getElementById('dashActiveTeam');
    const activeTimeRange = document.getElementById('dashActiveTimeRange');

    const nextIcon = document.getElementById('dashNextIcon');
    const nextShiftName = document.getElementById('dashNextShiftName');
    const nextTeamEl = document.getElementById('dashNextTeam');
    const nextTimeRange = document.getElementById('dashNextTimeRange');

    const count = this.shift.shiftsPer24h || 2;
    const dayStartStr = this.cal.toPersianDigits(this.shift.dayShiftStart || '07:00');
    const dayEndStr = this.cal.toPersianDigits(this.shift.dayShiftEnd || (count === 3 ? '15:00' : '19:00'));
    const eveStartStr = this.cal.toPersianDigits(this.shift.eveningShiftStart || '15:00');
    const eveEndStr = this.cal.toPersianDigits(this.shift.eveningShiftEnd || '23:00');
    const nightStartStr = this.cal.toPersianDigits(this.shift.nightShiftStart || (count === 3 ? '23:00' : '19:00'));
    const nightEndStr = this.cal.toPersianDigits(this.shift.nightShiftEnd || '07:00');

    if (count === 1) {
      if (status.isDayShift) {
        if (activeIcon) activeIcon.className = 'bi bi-sun-fill text-warning';
        if (activeShiftName) activeShiftName.textContent = 'روزکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-sun-fill text-warning';
        if (nextShiftName) nextShiftName.textContent = 'روزکاری بعدی';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;
      } else {
        if (activeIcon) activeIcon.className = 'bi bi-cup-hot text-info';
        if (activeShiftName) activeShiftName.textContent = 'استراحت / غیر شیفت';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = 'خارج از ساعت روزکاری';

        if (nextIcon) nextIcon.className = 'bi bi-sun-fill text-warning';
        if (nextShiftName) nextShiftName.textContent = 'روزکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;
      }
    } else if (count === 3) {
      if (status.isDayShift) {
        if (activeIcon) activeIcon.className = 'bi bi-sun-fill text-warning';
        if (activeShiftName) activeShiftName.textContent = 'روزکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-sunset-fill text-warning-emphasis';
        if (nextShiftName) nextShiftName.textContent = 'عصرکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${eveStartStr} الی ${eveEndStr}`;
      } else if (status.isEveningShift) {
        if (activeIcon) activeIcon.className = 'bi bi-sunset-fill text-warning-emphasis';
        if (activeShiftName) activeShiftName.textContent = 'عصرکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${eveStartStr} الی ${eveEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-moon-stars-fill';
        if (nextShiftName) nextShiftName.textContent = 'شبکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${nightStartStr} الی ${nightEndStr}`;
      } else {
        if (activeIcon) activeIcon.className = 'bi bi-moon-stars-fill';
        if (activeShiftName) activeShiftName.textContent = 'شبکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${nightStartStr} الی ${nightEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-sun-fill text-warning';
        if (nextShiftName) nextShiftName.textContent = 'روزکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;
      }
    } else {
      // 2 Shifts mode
      if (status.isDayShift) {
        if (activeIcon) activeIcon.className = 'bi bi-sun-fill text-warning';
        if (activeShiftName) activeShiftName.textContent = 'روزکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-moon-stars-fill';
        if (nextShiftName) nextShiftName.textContent = 'شبکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${nightStartStr} الی ${nightEndStr}`;
      } else {
        if (activeIcon) activeIcon.className = 'bi bi-moon-stars-fill';
        if (activeShiftName) activeShiftName.textContent = 'شبکاری';
        if (activeTeamEl) activeTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)}`;
        if (activeTimeRange) activeTimeRange.textContent = `${nightStartStr} الی ${nightEndStr}`;

        if (nextIcon) nextIcon.className = 'bi bi-sun-fill text-warning';
        if (nextShiftName) nextShiftName.textContent = 'روزکاری';
        if (nextTeamEl) nextTeamEl.textContent = `تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
        if (nextTimeRange) nextTimeRange.textContent = `${dayStartStr} الی ${dayEndStr}`;
      }
    }

    if (activeBox) activeBox.className = 'p-2 rounded-3 text-center transition-all active-shift-card';
    if (nextBox) nextBox.className = 'p-2 rounded-3 text-center transition-all next-shift-card';
  }

  /**
   * Starts live countdown tick every second
   */
  startCountdownTimer() {
    if (this.timerInterval) clearInterval(this.timerInterval);

    const tick = () => {
      const status = this.shift.getCurrentShiftStatus();

      const hoursEl = document.getElementById('timerHours');
      const minsEl = document.getElementById('timerMinutes');
      const secsEl = document.getElementById('timerSeconds');

      if (hoursEl) hoursEl.textContent = this.cal.toPersianDigits(String(status.remainingHours).padStart(2, '0'));
      if (minsEl) minsEl.textContent = this.cal.toPersianDigits(String(status.remainingMinutes).padStart(2, '0'));
      if (secsEl) secsEl.textContent = this.cal.toPersianDigits(String(status.remainingSeconds).padStart(2, '0'));

      const activeBadgeEl = document.getElementById('dashActiveShiftBadge');
      if (activeBadgeEl) {
        activeBadgeEl.textContent = `تیم ${this.cal.toPersianDigits(status.activeTeam)} (${status.activeShiftLabel} - فعال)`;
        activeBadgeEl.className = status.isDayShift ? 'badge badge-day-shift' : 'badge badge-night-shift';
      }

      const nextDetailsEl = document.getElementById('dashNextShiftDetails');
      if (nextDetailsEl) {
        nextDetailsEl.textContent = `شیفت بعدی: ${status.nextShiftLabel} تیم ${this.cal.toPersianDigits(status.nextShiftTeam)}`;
      }

      // Real-time active shift priority placement & highlighting
      this.updateDashboardActiveShift(status);

      // Instant shift boundary re-render check (e.g. at 07:00 / 19:00 exact switch)
      const currentShiftKey = `${status.isDayShift ? 'D' : 'N'}_${status.activeTeam}_${status.dayTeam}_${status.nightTeam}`;
      if (this.lastShiftKey && this.lastShiftKey !== currentShiftKey) {
        this.renderDashboard();
        this.renderCalendar();
      }
      this.lastShiftKey = currentShiftKey;
    };

    tick();
    this.timerInterval = setInterval(tick, 1000);
  }

  /**
   * Renders the Calendar grid for currentJalaliYear and currentJalaliMonth
   */
  renderCalendar() {
    const grid = document.getElementById('calendarDaysGrid');
    const title = document.getElementById('calMonthYearTitle');
    if (!grid) return;

    const jy = this.currentJalaliYear;
    const jm = this.currentJalaliMonth;
    const monthName = this.cal.jalaliMonthNames[jm - 1];

    if (title) title.textContent = `${monthName} ${this.cal.toPersianDigits(jy)}`;

    // Sync Month and Year selectors if present
    const monthSelect = document.getElementById('calMonthSelect');
    if (monthSelect && monthSelect.value !== String(jm)) {
      monthSelect.value = String(jm);
    }
    const yearInput = document.getElementById('calYearInput');
    if (yearInput && document.activeElement !== yearInput) {
      yearInput.value = jy;
    }

    const daysInMonth = this.cal.getJalaliMonthDays(jy, jm);
    const firstDayOfWeek = this.cal.getJalaliFirstDayOfWeek(jy, jm); // 0 = Sat, ..., 6 = Fri

    const now = new Date();
    const todayJ = this.cal.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());

    let html = '';

    // Empty lead cells for alignment
    for (let i = 0; i < firstDayOfWeek; i++) {
      html += '<div class="calendar-day-card bg-transparent border-0 opacity-0 pointer-events-none"></div>';
    }

    // Days of month
    for (let d = 1; d <= daysInMonth; d++) {
      const g = this.cal.jalaliToGregorian(jy, jm, d);
      const dateObj = new Date(g.gy, g.gm - 1, g.gd, 7, 0, 0);
      const dayOfWeekIndex = (dateObj.getDay() + 1) % 7; // 0 = Sat, 6 = Fri
      const isFriday = dayOfWeekIndex === 6;
      const isToday = (jy === todayJ.jy && jm === todayJ.jm && d === todayJ.jd);

      const teams = this.shift.getTeamsForDate(dateObj);
      const h = this.cal.gregorianToHijri(g.gy, g.gm, g.gd);
      const event = this.cal.getEventForDate(jm, d, jy, g.gm, g.gd, h.hm, h.hd);
      const dateStr = `${jy}-${String(jm).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayNotes = this.notes.getNotesForDate(dateStr);
      const isHoliday = isFriday || (event && event.holiday);

      let cardClasses = 'calendar-day-card';
      if (isHoliday) {
        cardClasses += ' holiday friday';
      } else {
        cardClasses += ' regular-day';
      }
      if (isToday) cardClasses += ' today';

      let teamBadgesHtml = '';
      if (teams.shiftsCount === 1) {
        teamBadgesHtml = `
          <div class="mini-team-box team-badge-${teams.dayTeam}" title="روزکاری: تیم ${teams.dayTeam}">
            <i class="bi bi-sun-fill"></i><span>${this.cal.toPersianDigits(teams.dayTeam)}</span>
          </div>
        `;
      } else if (teams.shiftsCount === 3) {
        teamBadgesHtml = `
          <div class="mini-team-box team-badge-${teams.dayTeam}" title="روزکاری: تیم ${teams.dayTeam}">
            <i class="bi bi-sun-fill"></i><span>${this.cal.toPersianDigits(teams.dayTeam)}</span>
          </div>
          <div class="mini-team-box team-badge-${teams.eveningTeam}" title="عصرکاری: تیم ${teams.eveningTeam}">
            <i class="bi bi-sunset-fill"></i><span>${this.cal.toPersianDigits(teams.eveningTeam)}</span>
          </div>
          <div class="mini-team-box team-badge-${teams.nightTeam}" title="شبکاری: تیم ${teams.nightTeam}">
            <i class="bi bi-moon-stars-fill"></i><span>${this.cal.toPersianDigits(teams.nightTeam)}</span>
          </div>
        `;
      } else {
        teamBadgesHtml = `
          <div class="mini-team-box team-badge-${teams.dayTeam}" title="روزکاری: تیم ${teams.dayTeam}">
            <i class="bi bi-sun-fill"></i><span>${this.cal.toPersianDigits(teams.dayTeam)}</span>
          </div>
          <div class="mini-team-box team-badge-${teams.nightTeam}" title="شبکاری: تیم ${teams.nightTeam}">
            <i class="bi bi-moon-stars-fill"></i><span>${this.cal.toPersianDigits(teams.nightTeam)}</span>
          </div>
        `;
      }

      html += `
        <div class="${cardClasses}" onclick="appController.openDayDetailModal(${jy}, ${jm}, ${d})">
          ${dayNotes.length > 0 ? '<span class="note-dot"></span>' : ''}
          <div class="calendar-day-header">
            <span class="calendar-day-number">${this.cal.toPersianDigits(d)}</span>
          </div>
          <div class="calendar-day-teams">
            ${teamBadgesHtml}
          </div>
        </div>
      `;
    }

    grid.innerHTML = html;
  }

  /**
   * Opens Day Detail Modal for today
   */
  openTodayModal() {
    const now = new Date();
    const j = this.cal.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    this.openDayDetailModal(j.jy, j.jm, j.jd);
  }

  /**
   * Opens Day Detail Modal for clicked calendar day
   */
  openDayDetailModal(jy, jm, jd) {
    this.selectedDayForModal = { jy, jm, jd };
    const g = this.cal.jalaliToGregorian(jy, jm, jd);
    const h = this.cal.gregorianToHijri(g.gy, g.gm, g.gd);
    const dateObj = new Date(g.gy, g.gm - 1, g.gd, 7, 0, 0);
    const dayOfWeekIndex = (dateObj.getDay() + 1) % 7;
    const weekDayName = this.cal.weekDayNames[dayOfWeekIndex];
    const monthName = this.cal.jalaliMonthNames[jm - 1];

    const teams = this.shift.getTeamsForDate(dateObj);
    const event = this.cal.getEventForDate(jm, jd, jy, g.gm, g.gd, h.hm, h.hd);
    const dateStr = `${jy}-${String(jm).padStart(2, '0')}-${String(jd).padStart(2, '0')}`;
    const dayNotes = this.notes.getNotesForDate(dateStr);

    document.getElementById('modalDayTitle').textContent = `${weekDayName} ${this.cal.toPersianDigits(jd)} ${monthName} ${this.cal.toPersianDigits(jy)}`;

    const modalGregEl = document.getElementById('modalGregorianDate');
    if (modalGregEl) {
      modalGregEl.textContent = `${g.gy}/${String(g.gm).padStart(2, '0')}/${String(g.gd).padStart(2, '0')} (${g.gd} ${this.cal.gregorianMonthNames[g.gm - 1]})`;
    }

    const modalHijriEl = document.getElementById('modalHijriDate');
    if (modalHijriEl) {
      modalHijriEl.textContent = `${this.cal.toPersianDigits(h.hd)} ${this.cal.hijriMonthNames[h.hm - 1] || ''} ${this.cal.toPersianDigits(h.hy)} هـ.ق`;
    }
    
    // Shift badges in modal
    const count = teams.shiftsCount || 2;
    const dayStartStr = this.cal.toPersianDigits(this.shift.dayShiftStart || '07:00');
    const dayEndStr = this.cal.toPersianDigits(this.shift.dayShiftEnd || (count === 3 ? '15:00' : '19:00'));
    const eveStartStr = this.cal.toPersianDigits(this.shift.eveningShiftStart || '15:00');
    const eveEndStr = this.cal.toPersianDigits(this.shift.eveningShiftEnd || '23:00');
    const nightStartStr = this.cal.toPersianDigits(this.shift.nightShiftStart || (count === 3 ? '23:00' : '19:00'));
    const nightEndStr = this.cal.toPersianDigits(this.shift.nightShiftEnd || '07:00');

    const dayShiftRow = document.getElementById('modalDayShiftRow');
    const dayShiftLabel = document.getElementById('modalDayShiftLabel');
    const dayBadge = document.getElementById('modalDayTeamBadge');

    const eveShiftRow = document.getElementById('modalEveningShiftRow');
    const eveShiftLabel = document.getElementById('modalEveningShiftLabel');
    const eveBadge = document.getElementById('modalEveningTeamBadge');

    const nightShiftRow = document.getElementById('modalNightShiftRow');
    const nightShiftLabel = document.getElementById('modalNightShiftLabel');
    const nightBadge = document.getElementById('modalNightTeamBadge');

    if (dayShiftRow) dayShiftRow.classList.remove('d-none');
    if (dayShiftLabel) dayShiftLabel.textContent = `شیفت روزکاری (${dayStartStr} - ${dayEndStr}):`;
    if (dayBadge) {
      dayBadge.textContent = `تیم ${this.cal.toPersianDigits(teams.dayTeam)}`;
      dayBadge.className = `badge team-badge team-badge-${teams.dayTeam}`;
    }

    if (count === 1) {
      if (eveShiftRow) eveShiftRow.classList.add('d-none');
      if (nightShiftRow) nightShiftRow.classList.add('d-none');
    } else if (count === 3) {
      if (eveShiftRow) eveShiftRow.classList.remove('d-none');
      if (eveShiftLabel) eveShiftLabel.textContent = `شیفت عصرکاری (${eveStartStr} - ${eveEndStr}):`;
      if (eveBadge) {
        eveBadge.textContent = `تیم ${this.cal.toPersianDigits(teams.eveningTeam)}`;
        eveBadge.className = `badge team-badge team-badge-${teams.eveningTeam}`;
      }

      if (nightShiftRow) nightShiftRow.classList.remove('d-none');
      if (nightShiftLabel) nightShiftLabel.textContent = `شیفت شبکاری (${nightStartStr} - ${nightEndStr}):`;
      if (nightBadge) {
        nightBadge.textContent = `تیم ${this.cal.toPersianDigits(teams.nightTeam)}`;
        nightBadge.className = `badge team-badge team-badge-${teams.nightTeam}`;
      }
    } else {
      // 2 Shifts
      if (eveShiftRow) eveShiftRow.classList.add('d-none');
      if (nightShiftRow) nightShiftRow.classList.remove('d-none');
      if (nightShiftLabel) nightShiftLabel.textContent = `شیفت شبکاری (${nightStartStr} - ${nightEndStr}):`;
      if (nightBadge) {
        nightBadge.textContent = `تیم ${this.cal.toPersianDigits(teams.nightTeam)}`;
        nightBadge.className = `badge team-badge team-badge-${teams.nightTeam}`;
      }
    }

    const eventText = document.getElementById('modalDayEventText');
    if (eventText) {
      const isFriday = dayOfWeekIndex === 6;
      const isHoliday = !!(event && event.holiday) || isFriday;
      if (isHoliday) {
        if (event && event.title) {
          eventText.textContent = `${event.title} (تعطیل)`;
        } else {
          eventText.textContent = 'تعطیل (جمعه)';
        }
        eventText.className = 'small text-danger fw-bold';
      } else {
        if (event && event.title) {
          eventText.textContent = event.title;
          eventText.className = 'small text-primary fw-bold';
        } else {
          eventText.textContent = 'بدون مناسبت';
          eventText.className = 'small text-muted';
        }
      }
    }

    const notesListEl = document.getElementById('modalDayNotesList');
    if (notesListEl) {
      if (dayNotes.length === 0) {
        notesListEl.innerHTML = '<p class="text-muted text-center py-2 mb-0">هیچ یادداشتی برای این روز ثبت نشده است.</p>';
      } else {
        let h = '<div class="list-group list-group-flush">';
        dayNotes.forEach(n => {
          h += `
            <div class="list-group-item bg-transparent px-0 d-flex justify-content-between align-items-center dash-note-item">
              <div>
                <div class="fw-bold dash-note-title">${n.title || 'بدون عنوان'}</div>
                <div class="dash-note-text small">${n.text}</div>
              </div>
              <button class="btn btn-sm btn-outline-danger border-0" onclick="appController.deleteNote('${n.id}')">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          `;
        });
        h += '</div>';
        notesListEl.innerHTML = h;
      }
    }

    this.showModal('dayDetailModal');
  }

  /**
   * Renders the Teams Page upcoming shifts (up to 10 shifts)
   */
  renderTeamPage() {
    const teamPicker = document.getElementById('teamSelectPicker');
    if (!teamPicker) return;

    const teamNum = parseInt(teamPicker.value, 10);

    const headerBadge = document.getElementById('teamBadgeHeader');
    if (headerBadge) {
      headerBadge.textContent = `تیم ${this.cal.toPersianDigits(teamNum)}`;
      headerBadge.className = `badge team-badge team-badge-${teamNum}`;
    }

    const titleEl = document.getElementById('teamStatsTitle');
    if (titleEl) {
      titleEl.textContent = `شیفت‌های تیم ${this.cal.toPersianDigits(teamNum)}`;
    }

    const count = this.shift.shiftsPer24h || 2;
    const dayStartStr = this.cal.toPersianDigits(this.shift.dayShiftStart || '07:00');
    const dayEndStr = this.cal.toPersianDigits(this.shift.dayShiftEnd || (count === 3 ? '15:00' : '19:00'));
    const eveStartStr = this.cal.toPersianDigits(this.shift.eveningShiftStart || '15:00');
    const eveEndStr = this.cal.toPersianDigits(this.shift.eveningShiftEnd || '23:00');
    const nightStartStr = this.cal.toPersianDigits(this.shift.nightShiftStart || (count === 3 ? '23:00' : '19:00'));
    const nightEndStr = this.cal.toPersianDigits(this.shift.nightShiftEnd || '07:00');

    // Render next 10 upcoming shifts for this team
    const upcomingListEl = document.getElementById('teamUpcomingShiftsList');
    if (upcomingListEl) {
      let curr = new Date();
      let found = 0;
      let html = '';

      for (let i = 0; i < 150 && found < 10; i++) {
        const teams = this.shift.getTeamsForDate(curr);
        const j = this.cal.gregorianToJalali(curr.getFullYear(), curr.getMonth() + 1, curr.getDate());
        const dayOfWeekIndex = (curr.getDay() + 1) % 7;
        const weekDayName = this.cal.weekDayNames[dayOfWeekIndex];
        const monthName = this.cal.jalaliMonthNames[j.jm - 1];

        let shiftType = null;
        let badgeClass = 'badge-day-shift';

        if (teams.dayTeam === teamNum) {
          shiftType = `روزکاری (${dayStartStr} - ${dayEndStr})`;
          badgeClass = 'badge-day-shift';
        } else if (teams.eveningTeam === teamNum) {
          shiftType = `عصرکاری (${eveStartStr} - ${eveEndStr})`;
          badgeClass = 'badge-evening-shift';
        } else if (teams.nightTeam === teamNum) {
          shiftType = `شبکاری (${nightStartStr} - ${nightEndStr})`;
          badgeClass = 'badge-night-shift';
        }

        if (shiftType) {
          found++;
          html += `
            <div class="list-group-item bg-transparent px-0 d-flex justify-content-between align-items-center upcoming-shift-item">
              <div>
                <span class="fw-bold upcoming-shift-date">${weekDayName} ${this.cal.toPersianDigits(j.jd)} ${monthName} ${this.cal.toPersianDigits(j.jy)}</span>
              </div>
              <span class="badge ${badgeClass}">${shiftType}</span>
            </div>
          `;
        }
        curr.setDate(curr.getDate() + 1);
      }

      upcomingListEl.innerHTML = html;
    }
  }

  /**
   * Renders Notes List tab
   */
  renderNotesList(searchQuery = '') {
    const listEl = document.getElementById('notesMainList');
    if (!listEl) return;

    const allNotes = searchQuery ? this.notes.searchNotes(searchQuery) : this.notes.getAllNotes();

    if (allNotes.length === 0) {
      listEl.innerHTML = '<div class="card p-4 text-center text-muted">یادداشتی یافت نشد.</div>';
      return;
    }

    let html = '';
    allNotes.forEach(n => {
      html += `
        <div class="card p-3 mb-2">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div>
              <span class="badge bg-secondary mb-1">${this.cal.toPersianDigits(n.dateStr || '')}</span>
              <h6 class="fw-bold mb-0 note-card-title">${n.title || 'بدون عنوان'}</h6>
            </div>
            <div>
              <button class="btn btn-sm btn-outline-info me-1" onclick="appController.openEditNoteModal('${n.id}')">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger" onclick="appController.deleteNote('${n.id}')">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </div>
          <p class="mb-0 note-card-text small">${n.text}</p>
        </div>
      `;
    });

    listEl.innerHTML = html;
  }

  /**
   * Opens Add Note Modal
   */
  openAddNoteModal() {
    document.getElementById('noteIdInput').value = '';
    document.getElementById('noteTitleInput').value = '';
    document.getElementById('noteTextInput').value = '';

    const todayG = new Date();
    const todayJ = this.cal.gregorianToJalali(todayG.getFullYear(), todayG.getMonth() + 1, todayG.getDate());
    let defaultDate = `${todayJ.jy}/${String(todayJ.jm).padStart(2, '0')}/${String(todayJ.jd).padStart(2, '0')}`;

    if (this.selectedDayForModal) {
      defaultDate = `${this.selectedDayForModal.jy}/${String(this.selectedDayForModal.jm).padStart(2, '0')}/${String(this.selectedDayForModal.jd).padStart(2, '0')}`;
    }

    document.getElementById('noteDateInput').value = defaultDate;
    document.getElementById('noteModalTitle').textContent = 'ثبت یادداشت جدید';

    this.showModal('addNoteModal');
  }

  /**
   * Opens Edit Note Modal
   */
  openEditNoteModal(noteId) {
    const notes = this.notes.getAllNotes();
    const target = notes.find(n => n.id === noteId);
    if (!target) return;

    document.getElementById('noteIdInput').value = target.id;
    document.getElementById('noteDateInput').value = target.dateStr ? target.dateStr.replace(/-/g, '/') : '';
    document.getElementById('noteTitleInput').value = target.title || '';
    document.getElementById('noteTextInput').value = target.text || '';
    document.getElementById('noteModalTitle').textContent = 'ویرایش یادداشت';

    this.showModal('addNoteModal');
  }

  /**
   * Saves Note from Modal Form
   */
  saveNoteFromModal() {
    const id = document.getElementById('noteIdInput').value;
    const dateInput = document.getElementById('noteDateInput').value.trim();
    const title = document.getElementById('noteTitleInput').value.trim();
    const text = document.getElementById('noteTextInput').value.trim();

    if (!text) {
      alert('لطفاً متن یادداشت را وارد کنید.');
      return;
    }

    // Convert date string format "1405/04/29" to "1405-04-29"
    const formattedDate = dateInput.replace(/\//g, '-');

    this.notes.saveNote({
      id: id || null,
      dateStr: formattedDate,
      title: title || 'بدون عنوان',
      text: text
    });

    this.hideModal('addNoteModal');

    this.renderDashboard();
    this.renderCalendar();
    this.renderNotesList();
  }

  /**
   * Deletes a Note
   */
  deleteNote(id) {
    if (confirm('آیا از حذف این یادداشت اطمینان دارید؟')) {
      this.notes.deleteNote(id);
      this.renderDashboard();
      this.renderCalendar();
      this.renderNotesList();

      const dayModalEl = document.getElementById('dayDetailModal');
      if (dayModalEl && this.selectedDayForModal) {
        this.openDayDetailModal(this.selectedDayForModal.jy, this.selectedDayForModal.jm, this.selectedDayForModal.jd);
      }
    }
  }

  /**
   * Populates Settings form with current localStorage values
   */
  populateSettingsForm() {
    const s = this.settings.settings;
    const darkSwitch = document.getElementById('settingsDarkSwitch');
    if (darkSwitch) darkSwitch.checked = s.darkMode;
    const fontSelect = document.getElementById('settingsFontSizeSelect');
    if (fontSelect) fontSelect.value = s.fontSize || 'normal';
    const teamsCountEl = document.getElementById('settingsTeamsCount');
    if (teamsCountEl) teamsCountEl.value = s.teamsCount || 5;
    const rotationEl = document.getElementById('settingsRotationOrder');
    if (rotationEl) rotationEl.value = (s.rotation || [1, 3, 5, 2, 4]).join(', ');
    const durationEl = document.getElementById('settingsShiftDuration');
    if (durationEl) durationEl.value = s.shiftDurationHours || 12;

    const shiftsPer24h = s.shiftsPer24h || 2;
    const shiftsSelect = document.getElementById('settingsShiftsPer24h');
    if (shiftsSelect) shiftsSelect.value = String(shiftsPer24h);

    // Toggle container visibility
    const c1 = document.getElementById('shifts1Container');
    const c2 = document.getElementById('shifts2Container');
    const c3 = document.getElementById('shifts3Container');
    if (c1) c1.classList.toggle('d-none', shiftsPer24h !== 1);
    if (c2) c2.classList.toggle('d-none', shiftsPer24h !== 2);
    if (c3) c3.classList.toggle('d-none', shiftsPer24h !== 3);

    // Mode 1: 1 Shift
    const s1DayStart = document.getElementById('settings1DayStart');
    if (s1DayStart) s1DayStart.value = s.dayShiftStart || '07:00';
    const s1DayEnd = document.getElementById('settings1DayEnd');
    if (s1DayEnd) s1DayEnd.value = s.dayShiftEnd || '15:00';

    // Mode 2: 2 Shifts
    const s2DayStart = document.getElementById('settings2DayStart');
    if (s2DayStart) s2DayStart.value = s.dayShiftStart || '07:00';
    const s2DayEnd = document.getElementById('settings2DayEnd');
    if (s2DayEnd) s2DayEnd.value = s.dayShiftEnd || '19:00';
    const s2NightStart = document.getElementById('settings2NightStart');
    if (s2NightStart) s2NightStart.value = s.nightShiftStart || '19:00';
    const s2NightEnd = document.getElementById('settings2NightEnd');
    if (s2NightEnd) s2NightEnd.value = s.nightShiftEnd || '07:00';

    // Mode 3: 3 Shifts
    const s3DayStart = document.getElementById('settings3DayStart');
    if (s3DayStart) s3DayStart.value = s.dayShiftStart || '07:00';
    const s3DayEnd = document.getElementById('settings3DayEnd');
    if (s3DayEnd) s3DayEnd.value = s.dayShiftEnd || '15:00';
    const s3EveningStart = document.getElementById('settings3EveningStart');
    if (s3EveningStart) s3EveningStart.value = s.eveningShiftStart || '15:00';
    const s3EveningEnd = document.getElementById('settings3EveningEnd');
    if (s3EveningEnd) s3EveningEnd.value = s.eveningShiftEnd || '23:00';
    const s3NightStart = document.getElementById('settings3NightStart');
    if (s3NightStart) s3NightStart.value = s.nightShiftStart || '23:00';
    const s3NightEnd = document.getElementById('settings3NightEnd');
    if (s3NightEnd) s3NightEnd.value = s.nightShiftEnd || '07:00';

    // Populate Base Ref Date & Ref Team
    const refDateEl = document.getElementById('settingsRefDate');
    if (refDateEl) {
      if (s.refDateJalali) {
        refDateEl.value = s.refDateJalali;
      } else {
        const refDate = s.refDateGregorian ? new Date(s.refDateGregorian) : new Date(2026, 6, 20, 7, 0, 0);
        const refJ = this.cal.gregorianToJalali(refDate.getFullYear(), refDate.getMonth() + 1, refDate.getDate());
        refDateEl.value = `${refJ.jy}/${String(refJ.jm).padStart(2, '0')}/${String(refJ.jd).padStart(2, '0')}`;
      }
    }

    const refTeamEl = document.getElementById('settingsRefTeam');
    if (refTeamEl) refTeamEl.value = s.refDayTeam || 2;

    const hijriOffsetEl = document.getElementById('settingsHijriOffset');
    if (hijriOffsetEl) hijriOffsetEl.value = String(s.hijriOffset !== undefined ? s.hijriOffset : 0);
  }

  /**
   * Saves Settings from Settings Form
   */
  saveSettingsFromForm() {
    const s = this.settings.settings;
    const darkSwitch = document.getElementById('settingsDarkSwitch');
    const darkMode = darkSwitch ? darkSwitch.checked : (s.darkMode !== undefined ? s.darkMode : true);
    const fontSelect = document.getElementById('settingsFontSizeSelect');
    const fontSize = fontSelect ? fontSelect.value : (s.fontSize || 'normal');
    const hijriOffsetEl = document.getElementById('settingsHijriOffset');
    const hijriOffset = hijriOffsetEl ? parseInt(hijriOffsetEl.value, 10) || 0 : 0;
    const teamsCount = parseInt(document.getElementById('settingsTeamsCount').value, 10);
    const rotationStr = document.getElementById('settingsRotationOrder').value;
    const rotation = rotationStr.split(',').map(x => parseInt(x.trim(), 10)).filter(x => !isNaN(x));

    const shiftsSelect = document.getElementById('settingsShiftsPer24h');
    const shiftsPer24h = shiftsSelect ? parseInt(shiftsSelect.value, 10) || 2 : 2;

    let shiftDurationHours = 12;
    let dayShiftStart = '07:00';
    let dayShiftEnd = '19:00';
    let eveningShiftStart = '15:00';
    let eveningShiftEnd = '23:00';
    let nightShiftStart = '19:00';
    let nightShiftEnd = '07:00';

    if (shiftsPer24h === 1) {
      shiftDurationHours = 8;
      dayShiftStart = document.getElementById('settings1DayStart')?.value || '07:00';
      dayShiftEnd = document.getElementById('settings1DayEnd')?.value || '15:00';
    } else if (shiftsPer24h === 3) {
      shiftDurationHours = 8;
      dayShiftStart = document.getElementById('settings3DayStart')?.value || '07:00';
      dayShiftEnd = document.getElementById('settings3DayEnd')?.value || '15:00';
      eveningShiftStart = document.getElementById('settings3EveningStart')?.value || '15:00';
      eveningShiftEnd = document.getElementById('settings3EveningEnd')?.value || '23:00';
      nightShiftStart = document.getElementById('settings3NightStart')?.value || '23:00';
      nightShiftEnd = document.getElementById('settings3NightEnd')?.value || '07:00';
    } else {
      // 2 Shifts
      shiftDurationHours = 12;
      dayShiftStart = document.getElementById('settings2DayStart')?.value || '07:00';
      dayShiftEnd = document.getElementById('settings2DayEnd')?.value || '19:00';
      nightShiftStart = document.getElementById('settings2NightStart')?.value || '19:00';
      nightShiftEnd = document.getElementById('settings2NightEnd')?.value || '07:00';
    }

    const durationInput = document.getElementById('settingsShiftDuration');
    if (durationInput && durationInput.value) {
      const parsedDur = parseInt(durationInput.value, 10);
      if (!isNaN(parsedDur) && parsedDur > 0) shiftDurationHours = parsedDur;
    }

    const dayShiftStartHour = parseInt(dayShiftStart.split(':')[0], 10) || 7;
    const nightShiftStartHour = parseInt(nightShiftStart.split(':')[0], 10) || (shiftsPer24h === 3 ? 23 : 19);

    const refTeamEl = document.getElementById('settingsRefTeam');
    const refDayTeam = refTeamEl ? parseInt(refTeamEl.value, 10) || 2 : 2;

    // Helper to convert Persian/Arabic digits to English digits
    const toEnglishDigits = (str) => {
      return str.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
                .replace(/[٠-٩]/g, d => '٠١٢٣٥٦٧٨٩'.indexOf(d));
    };

    const refDateInput = document.getElementById('settingsRefDate') ? document.getElementById('settingsRefDate').value.trim() : '';
    let refDateGregorianIso = null;
    let refDateJalaliFormatted = refDateInput;

    if (refDateInput) {
      const cleanRefDate = toEnglishDigits(refDateInput).replace(/[-.]/g, '/');
      const parts = cleanRefDate.split('/').map(x => parseInt(x.trim(), 10));
      if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        const [jy, jm, jd] = parts;
        const g = this.cal.jalaliToGregorian(jy, jm, jd);
        const gDate = new Date(g.gy, g.gm - 1, g.gd, dayShiftStartHour, 0, 0);
        refDateGregorianIso = gDate.toISOString();
        refDateJalaliFormatted = `${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`;
      } else {
        alert('لطفاً تاریخ مبدأ را به صورت صحیح وارد کنید (مثال: ۱۴۰۵/۰۴/۲۹)');
        return;
      }
    }

    const updatedSettings = {
      darkMode,
      fontSize,
      hijriOffset,
      teamsCount,
      rotation,
      shiftsPer24h,
      dayShiftStart,
      dayShiftEnd,
      eveningShiftStart,
      eveningShiftEnd,
      nightShiftStart,
      nightShiftEnd,
      shiftDurationHours,
      dayShiftStartHour,
      nightShiftStartHour,
      refDayTeam
    };

    if (refDateGregorianIso) {
      updatedSettings.refDateGregorian = refDateGregorianIso;
      updatedSettings.refDateJalali = refDateJalaliFormatted;
    }

    this.settings.saveSettings(updatedSettings);

    if (this.shift && typeof this.shift.initDefaults === 'function') {
      this.shift.initDefaults();
    }

    alert('تنظیمات موتور شیفت با موفقیت ذخیره شد.');
    this.initUI();
  }

  /**
   * Opens Backup/Restore Modal
   */
  openBackupModal() {
    const backupText = this.notes.exportBackupJSON();
    const exportEl = document.getElementById('backupExportText');
    if (exportEl) exportEl.value = backupText;
    const importEl = document.getElementById('backupImportText');
    if (importEl) importEl.value = '';

    this.showModal('backupModal');
  }

  /**
   * Restores JSON Backup Data
   */
  restoreDataFromModal() {
    const importText = document.getElementById('backupImportText').value.trim();
    if (!importText) {
      alert('لطفاً متن پشتیبان (JSON) را وارد کنید.');
      return;
    }

    if (this.notes.importRestoreJSON(importText)) {
      alert('اطلاعات و تنظیمات با موفقیت بازگردانی شدند.');
      location.reload();
    } else {
      alert('خطا در بازگردانی! ساختار فایل پشتیبان معتبر نیست.');
    }
  }

  /**
   * Attaches event listeners across all controls
   */
  attachEventListeners() {
    // Calendar Month Navigation
    const prevMonthBtn = document.getElementById('calPrevMonthBtn');
    if (prevMonthBtn) {
      prevMonthBtn.addEventListener('click', () => {
        this.currentJalaliMonth--;
        if (this.currentJalaliMonth < 1) {
          this.currentJalaliMonth = 12;
          this.currentJalaliYear--;
        }
        this.renderCalendar();
      });
    }

    const nextMonthBtn = document.getElementById('calNextMonthBtn');
    if (nextMonthBtn) {
      nextMonthBtn.addEventListener('click', () => {
        this.currentJalaliMonth++;
        if (this.currentJalaliMonth > 12) {
          this.currentJalaliMonth = 1;
          this.currentJalaliYear++;
        }
        this.renderCalendar();
      });
    }

    const todayJumpBtn = document.getElementById('calTodayJumpBtn');
    if (todayJumpBtn) {
      todayJumpBtn.addEventListener('click', () => {
        const now = new Date();
        const j = this.cal.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
        this.currentJalaliYear = j.jy;
        this.currentJalaliMonth = j.jm;
        this.renderCalendar();
      });
    }

    // Direct Calendar Month and Year Selectors
    const monthSelect = document.getElementById('calMonthSelect');
    if (monthSelect) {
      monthSelect.addEventListener('change', (e) => {
        const selectedMonth = parseInt(e.target.value, 10);
        if (!isNaN(selectedMonth) && selectedMonth >= 1 && selectedMonth <= 12) {
          this.currentJalaliMonth = selectedMonth;
          this.renderCalendar();
        }
      });
    }

    // Direct Calendar Year Input (Allows typing any custom Jalali year)
    const yearInput = document.getElementById('calYearInput');
    if (yearInput) {
      const applyTypedYear = (force = false) => {
        const rawVal = this.cal.toEnglishDigits(yearInput.value.trim());
        const selectedYear = parseInt(rawVal, 10);
        if (!isNaN(selectedYear) && selectedYear >= 1200 && selectedYear <= 1600) {
          if (this.currentJalaliYear !== selectedYear) {
            this.currentJalaliYear = selectedYear;
            this.renderCalendar();
          }
        } else if (force) {
          // Revert to current year if invalid on blur/enter
          yearInput.value = this.currentJalaliYear;
        }
      };

      yearInput.addEventListener('change', () => applyTypedYear(true));
      yearInput.addEventListener('blur', () => applyTypedYear(true));
      yearInput.addEventListener('input', () => {
        const rawVal = this.cal.toEnglishDigits(yearInput.value.trim());
        if (rawVal.length === 4) {
          applyTypedYear(false);
        }
      });
      yearInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          applyTypedYear(true);
          yearInput.blur();
        }
      });
    }

    // Team Picker Change
    const teamPicker = document.getElementById('teamSelectPicker');
    if (teamPicker) {
      teamPicker.addEventListener('change', () => this.renderTeamPage());
    }

    // Date Converter Run Button
    const convBtn = document.getElementById('btnRunConversion');
    if (convBtn) {
      convBtn.addEventListener('click', () => {
        const jy = parseInt(document.getElementById('convYear').value, 10);
        const jm = parseInt(document.getElementById('convMonth').value, 10);
        const jd = parseInt(document.getElementById('convDay').value, 10);

        const res = this.converter.convertFromJalali(jy, jm, jd);

        document.getElementById('convResultDayName').textContent = `${res.weekDayName} - ${this.cal.toPersianDigits(res.jalali.day)} ${res.jalali.monthName} ${this.cal.toPersianDigits(res.jalali.year)}`;
        document.getElementById('convResultGregorian').textContent = `${res.gregorian.day} ${res.gregorian.monthName} ${res.gregorian.year} (${res.gregorian.formatted})`;
        document.getElementById('convResultHijri').textContent = `${this.cal.toPersianDigits(res.hijri.day)} ${res.hijri.monthName} ${this.cal.toPersianDigits(res.hijri.year)} هـ.ق`;
        document.getElementById('convResultWeekNum').textContent = this.cal.toPersianDigits(res.weekNumber);

        const dayBadge = document.getElementById('convResultDayTeam');
        if (dayBadge) {
          dayBadge.textContent = `تیم ${this.cal.toPersianDigits(res.dayTeam)}`;
          dayBadge.className = `badge team-badge team-badge-${res.dayTeam}`;
        }

        const nightBadge = document.getElementById('convResultNightTeam');
        if (nightBadge) {
          nightBadge.textContent = `تیم ${this.cal.toPersianDigits(res.nightTeam)}`;
          nightBadge.className = `badge team-badge team-badge-${res.nightTeam}`;
        }
      });
    }

    // Notes Search
    const notesSearch = document.getElementById('notesSearchInput');
    if (notesSearch) {
      notesSearch.addEventListener('input', (e) => this.renderNotesList(e.target.value));
    }

    // Modal Action Buttons
    const btnSaveNote = document.getElementById('btnSaveNote');
    if (btnSaveNote) {
      btnSaveNote.addEventListener('click', () => this.saveNoteFromModal());
    }

    const modalAddNoteForDayBtn = document.getElementById('modalAddNoteForDayBtn');
    if (modalAddNoteForDayBtn) {
      modalAddNoteForDayBtn.addEventListener('click', () => {
        this.hideModal('dayDetailModal');
        this.openAddNoteModal();
      });
    }

    const btnSaveSettings = document.getElementById('btnSaveSettings');
    if (btnSaveSettings) {
      btnSaveSettings.addEventListener('click', () => this.saveSettingsFromForm());
    }

    // Dynamic Shifts Per 24h Selector
    const shiftsSelect = document.getElementById('settingsShiftsPer24h');
    if (shiftsSelect) {
      shiftsSelect.addEventListener('change', (e) => {
        const count = parseInt(e.target.value, 10);
        const c1 = document.getElementById('shifts1Container');
        const c2 = document.getElementById('shifts2Container');
        const c3 = document.getElementById('shifts3Container');
        const durationEl = document.getElementById('settingsShiftDuration');

        if (c1) c1.classList.toggle('d-none', count !== 1);
        if (c2) c2.classList.toggle('d-none', count !== 2);
        if (c3) c3.classList.toggle('d-none', count !== 3);

        if (durationEl) {
          if (count === 1) durationEl.value = 8;
          else if (count === 2) durationEl.value = 12;
          else if (count === 3) durationEl.value = 8;
        }
      });
    }

    const btnCopyBackup = document.getElementById('btnCopyBackupText');
    if (btnCopyBackup) {
      btnCopyBackup.addEventListener('click', () => {
        const copyText = document.getElementById('backupExportText');
        copyText.select();
        navigator.clipboard.writeText(copyText.value).then(() => {
          alert('کد پشتیبان کپی شد.');
        });
      });
    }

    const btnRestoreData = document.getElementById('btnRestoreData');
    if (btnRestoreData) {
      btnRestoreData.addEventListener('click', () => this.restoreDataFromModal());
    }

    // PDF Export Event Listeners
    const btnExportMonthPdf = document.getElementById('btnExportMonthPdf');
    if (btnExportMonthPdf) {
      btnExportMonthPdf.addEventListener('click', () => {
        const jy = this.currentJalaliYear;
        const jm = this.currentJalaliMonth;
        if (window.pdfPrintEngine) {
          window.pdfPrintEngine.generatePrintableMonthlyCalendar(jy, jm, 0);
        }
      });
    }

    const btnExportTeamPdf = document.getElementById('btnExportTeamPdf');
    if (btnExportTeamPdf) {
      btnExportTeamPdf.addEventListener('click', () => {
        const jy = this.currentJalaliYear;
        const jm = this.currentJalaliMonth;
        const picker = document.getElementById('teamSelectPicker');
        const teamNum = picker ? parseInt(picker.value, 10) : 2;
        if (window.pdfPrintEngine) {
          window.pdfPrintEngine.generatePrintableMonthlyCalendar(jy, jm, teamNum);
        }
      });
    }

    // Global Search
    const globalSearchInput = document.getElementById('globalSearchInput');
    if (globalSearchInput) {
      globalSearchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        const resultsBox = document.getElementById('globalSearchResults');
        if (!query) {
          resultsBox.innerHTML = '<p class="text-muted text-center py-3 mb-0">عبارت مورد نظر خود را وارد کنید.</p>';
          return;
        }

        const matchedNotes = this.notes.searchNotes(query);
        let html = '<h6 class="fw-bold mb-2">نتایج یادداشت‌ها:</h6>';

        if (matchedNotes.length === 0) {
          html += '<p class="small text-muted mb-3">یادداشتی با این عبارت یافت نشد.</p>';
        } else {
          html += '<div class="list-group list-group-flush mb-3">';
          matchedNotes.forEach(n => {
            html += `<div class="list-group-item bg-transparent text-white px-0"><span class="text-warning fw-bold">${n.title}</span> - ${n.text}</div>`;
          });
          html += '</div>';
        }

        resultsBox.innerHTML = html;
      });
    }

    // Modal Lifecycle Synchronization
    document.querySelectorAll('.modal').forEach(modalEl => {
      modalEl.addEventListener('hidden.bs.modal', () => {
        this.activeModals = this.activeModals.filter(id => id !== modalEl.id);
      });
    });

    // Browser Popstate / Back button listener
    window.addEventListener('popstate', () => {
      this.handleBack();
    });

    // Keyboard Back / Escape key handling
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.handleBack();
      }
    });
  }
}

// Global instance
window.appController = new AppController();
