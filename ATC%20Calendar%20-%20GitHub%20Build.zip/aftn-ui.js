/**
 * Stale Cache Cleanup Stub
 * Automatically purges AFTN UI and forces navigation away if stale cache loads this file.
 */
(function() {
  try {
    function purgeAftn() {
      const selectors = ['#tab-aftn', '.aftn-home-widget', '[data-tab="aftn"]', '#aftnViewContainer'];
      selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => el.remove());
      });
      if (window.appController && window.appController.currentTab === 'aftn') {
        window.appController.switchTab('home');
      }
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', purgeAftn);
    } else {
      purgeAftn();
    }
  } catch(e) {}
})();
window.aftnUI = {
  init: () => {
    document.querySelectorAll('#tab-aftn, .aftn-home-widget, [data-tab="aftn"]').forEach(el => el.remove());
  }
};
