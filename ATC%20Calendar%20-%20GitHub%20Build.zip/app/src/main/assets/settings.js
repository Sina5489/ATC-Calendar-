/**
 * settings.js
 * Settings Engine for Taghvim Sina (تقویم سینا)
 * Handles theme toggling (Dark/Light Mode), team colors, font sizes, shift parameters, and localStorage.
 */

class SettingsManager {
  constructor() {
    this.STORAGE_KEY = 'taghvim_sina_settings';
    this.defaultSettings = {
      darkMode: false,
      fontSize: 'normal', // 'normal', 'medium', 'large'
      hijriOffset: 0, // Day adjustment offset (-2 to +2)
      teamsCount: 5,
      rotation: [1, 3, 5, 2, 4],
      shiftsPer24h: 2, // 1, 2, or 3
      shiftDurationHours: 12,
      dayShiftStart: '07:00',
      dayShiftEnd: '19:00',
      eveningShiftStart: '15:00',
      eveningShiftEnd: '23:00',
      nightShiftStart: '19:00',
      nightShiftEnd: '07:00',
      dayShiftStartHour: 7,
      nightShiftStartHour: 19,
      refDayTeam: 2,
      refDateJalali: '1405/04/29',
      refDateGregorian: '2026-07-20T07:00:00.000Z', // 29 Tir 1405 07:00
      teamColors: {
        1: '#3B82F6', // Blue
        2: '#10B981', // Emerald Green
        3: '#F59E0B', // Amber
        4: '#EC4899', // Pink
        5: '#8B5CF6'  // Purple
      }
    };

    this.settings = this.loadSettings();
    this.applySettingsUI();
  }

  /**
   * Loads settings from LocalStorage or returns defaults
   * @returns {Object} Settings object
   */
  loadSettings() {
    try {
      const saved = localStorage.getItem(this.STORAGE_KEY);
      return saved ? { ...this.defaultSettings, ...JSON.parse(saved) } : { ...this.defaultSettings };
    } catch (e) {
      return { ...this.defaultSettings };
    }
  }

  /**
   * Saves settings to LocalStorage and applies changes
   * @param {Object} newSettings
   */
  saveSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.settings));
    this.applySettingsUI();

    // Notify Shift Calculator
    if (window.shiftCalculator) {
      window.shiftCalculator.initDefaults();
    }
  }

  /**
   * Applies CSS theme classes and root CSS variables based on current settings
   */
  applySettingsUI() {
    const root = document.documentElement;
    if (root) {
      root.setAttribute('data-bs-theme', 'light');
      if (root.classList) {
        root.classList.remove('font-size-normal', 'font-size-medium', 'font-size-large');
        root.classList.add(`font-size-${this.settings.fontSize || 'normal'}`);
      }
      if (this.settings.teamColors && root.style) {
        Object.keys(this.settings.teamColors).forEach(teamId => {
          root.style.setProperty(`--team-color-${teamId}`, this.settings.teamColors[teamId]);
        });
      }
    }

    // Body Theme
    if (document.body && document.body.classList) {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
    } else {
      // Defer until DOM is ready if body not yet loaded
      if (typeof window !== 'undefined' && window.addEventListener) {
        window.addEventListener('DOMContentLoaded', () => {
          if (document.body && document.body.classList) {
            document.body.classList.remove('dark-theme');
            document.body.classList.add('light-theme');
          }
        }, { once: true });
      }
    }
  }

  /**
   * Toggles Dark Mode
   */
  toggleDarkMode() {
    this.saveSettings({ darkMode: !this.settings.darkMode });
  }
}

// Global instance
window.settingsManager = new SettingsManager();
