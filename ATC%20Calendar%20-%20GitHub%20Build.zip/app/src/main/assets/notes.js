/**
 * notes.js
 * Notes Management for Taghvim Sina (تقویم سینا)
 * Provides note creation, editing, deletion, search, JSON backup and restore.
 */

class NotesManager {
  constructor() {
    this.STORAGE_KEY = 'taghvim_sina_notes';
  }

  /**
   * Retrieves all notes from LocalStorage
   * @returns {Array} List of note objects
   */
  getAllNotes() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Failed to parse notes from LocalStorage', e);
      return [];
    }
  }

  /**
   * Saves notes list to LocalStorage
   * @param {Array} notes
   */
  saveNotes(notes) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(notes));
  }

  /**
   * Adds or updates a note
   * @param {Object} noteObj { id, dateStr, title, text, priority }
   * @returns {Object} saved note
   */
  saveNote(noteObj) {
    const notes = this.getAllNotes();
    if (!noteObj.id) {
      noteObj.id = 'note_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
      noteObj.createdAt = new Date().toISOString();
      notes.unshift(noteObj);
    } else {
      const index = notes.findIndex(n => n.id === noteObj.id);
      if (index !== -1) {
        notes[index] = { ...notes[index], ...noteObj, updatedAt: new Date().toISOString() };
      } else {
        notes.unshift(noteObj);
      }
    }
    this.saveNotes(notes);
    return noteObj;
  }

  /**
   * Deletes a note by ID
   * @param {string} id
   */
  deleteNote(id) {
    let notes = this.getAllNotes();
    notes = notes.filter(n => n.id !== id);
    this.saveNotes(notes);
  }

  /**
   * Gets notes for a specific Jalali date string (e.g. "1405-04-29")
   * @param {string} dateStr
   * @returns {Array}
   */
  getNotesForDate(dateStr) {
    const notes = this.getAllNotes();
    return notes.filter(n => n.dateStr === dateStr);
  }

  /**
   * Searches notes by text or date
   * @param {string} query
   * @returns {Array}
   */
  searchNotes(query) {
    if (!query || !query.trim()) return this.getAllNotes();
    const q = query.trim().toLowerCase();
    return this.getAllNotes().filter(n =>
      (n.title && n.title.toLowerCase().includes(q)) ||
      (n.text && n.text.toLowerCase().includes(q)) ||
      (n.dateStr && n.dateStr.includes(q))
    );
  }

  /**
   * Exports full application data (notes + settings) as JSON object
   * @returns {string} JSON string
   */
  exportBackupJSON() {
    const backupObj = {
      app: 'TaghvimSina',
      version: '1.0',
      exportDate: new Date().toISOString(),
      notes: this.getAllNotes(),
      settings: JSON.parse(localStorage.getItem('taghvim_sina_settings') || '{}')
    };
    return JSON.stringify(backupObj, null, 2);
  }

  /**
   * Restores application data from JSON string
   * @param {string} jsonString
   * @returns {boolean} Success status
   */
  importRestoreJSON(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (data && Array.isArray(data.notes)) {
        this.saveNotes(data.notes);
        if (data.settings) {
          localStorage.setItem('taghvim_sina_settings', JSON.stringify(data.settings));
        }
        return true;
      }
      return false;
    } catch (e) {
      console.error('Invalid restore JSON format', e);
      return false;
    }
  }
}

// Global instance
window.notesManager = new NotesManager();
