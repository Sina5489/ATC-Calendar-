package com.example

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WebView.setWebContentsDebuggingEnabled(true)
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PwaWebView()
                }
            }
        }
    }
}

class AndroidShareBridge(
    private val context: Context,
    private val webViewSupplier: () -> WebView?
) {
    @JavascriptInterface
    fun shareText(title: String, text: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "$title\n$text")
        }
        context.startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری برنامه شیفت"))
    }

    @JavascriptInterface
    fun exitApp() {
        (context as? ComponentActivity)?.runOnUiThread {
            (context as? ComponentActivity)?.finish()
        }
    }

    @JavascriptInterface
    fun print() {
        val webView = webViewSupplier() ?: return
        (context as? ComponentActivity)?.runOnUiThread {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return@runOnUiThread
            val printAdapter = webView.createPrintDocumentAdapter("Taghvim_Sina_Shift_Report")
            val builder = PrintAttributes.Builder().build()
            printManager.print("Taghvim Sina Schedule", printAdapter, builder)
        }
    }

    @JavascriptInterface
    fun readAsset(fileName: String): String {
        return try {
            context.assets.open(fileName).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e("TaghvimSinaBridge", "Failed to read asset: $fileName", e)
            ""
        }
    }

    @JavascriptInterface
    fun getGeminiApiKey(): String {
        return BuildConfig.GEMINI_API_KEY
    }

    @JavascriptInterface
    fun fetchNative(urlStr: String, method: String = "GET", body: String? = null, headersJson: String? = null): String {
        return try {
            val url = URL(urlStr)
            val conn = url.openConnection() as HttpURLConnection
            if (conn is HttpsURLConnection) {
                val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                    override fun getAcceptedIssuers(): Array<X509Certificate>? = null
                    override fun checkClientTrusted(certs: Array<X509Certificate>?, authType: String?) {}
                    override fun checkServerTrusted(certs: Array<X509Certificate>?, authType: String?) {}
                })
                val sc = SSLContext.getInstance("SSL")
                sc.init(null, trustAllCerts, SecureRandom())
                conn.sslSocketFactory = sc.socketFactory
                conn.setHostnameVerifier { _, _ -> true }
            }
            conn.requestMethod = method.uppercase()
            conn.connectTimeout = 15000
            conn.readTimeout = 20000

            if (!headersJson.isNullOrBlank()) {
                try {
                    val headersObj = JSONObject(headersJson)
                    val keys = headersObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        conn.setRequestProperty(key, headersObj.getString(key))
                    }
                } catch (e: Exception) {
                    Log.w("TaghvimSinaBridge", "Failed to parse custom headers: ${e.message}")
                }
            }

            if (!body.isNullOrBlank() && (method.equals("POST", ignoreCase = true) || method.equals("PUT", ignoreCase = true))) {
                conn.doOutput = true
                conn.outputStream.use { os ->
                    os.write(body.toByteArray(Charsets.UTF_8))
                }
            }

            val responseCode = conn.responseCode
            val isSuccess = responseCode in 200..299
            val inputStream = if (isSuccess) conn.inputStream else conn.errorStream ?: conn.inputStream
            val responseText = inputStream.bufferedReader().use { it.readText() }

            val result = JSONObject().apply {
                put("ok", isSuccess)
                put("status", responseCode)
                put("data", responseText)
                put("url", urlStr)
            }
            result.toString()
        } catch (e: Exception) {
            Log.e("TaghvimSinaBridge", "Native fetch failed for: $urlStr", e)
            val result = JSONObject().apply {
                put("ok", false)
                put("status", 0)
                put("error", e.message ?: "Network error")
                put("url", urlStr)
            }
            result.toString()
        }
    }
}

@Composable
fun PwaWebView(modifier: Modifier = Modifier) {
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    val lastBackPressTime = remember { mutableLongStateOf(0L) }

    BackHandler {
        val webView = webViewRef.value
        if (webView != null && webView.canGoBack()) {
            webView.goBack()
        } else {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastBackPressTime.longValue < 2000) {
                (webView?.context as? ComponentActivity)?.finish()
            } else {
                lastBackPressTime.longValue = currentTime
                webView?.context?.let { ctx ->
                    Toast.makeText(ctx, "برای خروج دوباره دکمه بازگشت را بزنید", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                clearCache(true)
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = true
                    allowContentAccess = true
                    databaseEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    cacheMode = WebSettings.LOAD_NO_CACHE
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        Log.d("PwaConsole", "${consoleMessage?.message()} -- From line ${consoleMessage?.lineNumber()} of ${consoleMessage?.sourceId()}")
                        return true
                    }

                    override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                        AlertDialog.Builder(ctx)
                            .setTitle("ATC Calendar")
                            .setMessage(message)
                            .setPositiveButton("تایید") { _, _ -> result?.confirm() }
                            .setOnCancelListener { result?.cancel() }
                            .show()
                        return true
                    }

                    override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                        AlertDialog.Builder(ctx)
                            .setTitle("ATC Calendar")
                            .setMessage(message)
                            .setPositiveButton("بله") { _, _ -> result?.confirm() }
                            .setNegativeButton("خیر") { _, _ -> result?.cancel() }
                            .setOnCancelListener { result?.cancel() }
                            .show()
                        return true
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        return false
                    }
                }

                addJavascriptInterface(AndroidShareBridge(ctx) { webViewRef.value }, "AndroidShare")
                clearCache(true)
                loadUrl("file:///android_asset/index.html?v=" + System.currentTimeMillis())
                webViewRef.value = this
            }
        },
        modifier = modifier.fillMaxSize()
    )
}
